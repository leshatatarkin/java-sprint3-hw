package manager;

import task.*;

import java.util.List;

public interface HistoryManager {
    void add(Task task); // помечать задачи как просмотренные
    void remove(int id); // удаление задачи из просмотра
    List<Task> getHistory(); //возвращать список просмотренных задач
}
