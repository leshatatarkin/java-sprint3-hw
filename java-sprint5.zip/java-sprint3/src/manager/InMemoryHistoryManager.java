package manager;

import task.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class InMemoryHistoryManager<T> implements HistoryManager {

    private final int countHistory = 9;
    public static DoublyLinkedList obj; // связанный список
    private Map<Integer, Node<T>> historyMap; // id - ключ

    public InMemoryHistoryManager() {
        historyMap = new HashMap<>();
        obj = new DoublyLinkedList();
    }

    @Override
    public List<Task> getHistory() {
        List<Task> list = new ArrayList<>();
        List<Node<T>> listNode = obj.getTasks();
        for (Node<T> tNode : listNode) {
            list.add((Task) tNode.data);
        }

        System.out.println("Просмотренные задачи:");
        for (Task task : list) {
            System.out.println(task);
        }
        return list;
    }

    @Override
    public void add(Task task) {
        Node<T> newObj = new Node(task);
        if (historyMap.containsKey(task.getId())) {
            obj.removeNode(historyMap.get(task.getId()));
        }
        historyMap.put(task.getId(), newObj);
        obj.linkLast(newObj);
    }

    @Override
    public void remove(int id) {
        //listTask.remove(id);
    }

    public static class DoublyLinkedList<T> {
        public Node<T> head;
        public Node<T> tail;
        public int size = 0;
        public List<Node<T>> list; // Список узлов

        public void linkLast(Node<T> newObj) { // добавлять задачу в конец этого списка
            if (size == 0) {
                head = newObj;
                tail = newObj;
            } else {
                newObj.prev = tail;
                tail.next = newObj;
                tail = newObj;
            }
            size++;
        }

        public List<Node<T>> getTasks() { //собирать все задачи из него
            list = new ArrayList<>();
            Node<T> link = head;
            for (int i = 0; i < size; i++) {
                list.add(link);
                link = link.next;
            }
            return list;
        }

        public void removeNode(Node<T> node) {
            if (node == head) {
                head = node.next;
                node.next.prev = null;
            } else if (node == tail) {
                tail = node.prev;
                node.prev.next = null;
            } else {
                node.prev.next = node.next;
                node.next.prev = node.prev;
            }
            size--;

        }
    }

}
