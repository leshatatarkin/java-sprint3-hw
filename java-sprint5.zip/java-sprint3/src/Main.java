import manager.*;
import task.Epic;
import task.Subtask;
import task.Task;

import java.util.List;

public class Main {
    public static void main(String[] args) {

        TaskManager inMemoryTaskManager = Managers.getDefault();

        //создаем объекты
        inMemoryTaskManager.create(new Task("Таск 1", "описание Таск 1"));
        inMemoryTaskManager.create(new Task("Таск 2", "описание Таск 2"));

        inMemoryTaskManager.create(new Epic("Эпик 1", "описание Эпик 1"));
        inMemoryTaskManager.create(new Subtask("Сабтаск 1", "описание Сабтаск 1", 3));
        inMemoryTaskManager.create(new Subtask("Сабтаск 2", "описание Сабтаск 2", 3));
        inMemoryTaskManager.create(new Subtask("Сабтаск 3", "описание Сабтаск 3", 3));

        inMemoryTaskManager.create(new Epic("Эпик 2", "описание Эпик 2"));


        //печатаем все объекты
        inMemoryTaskManager.printAllTypeTask();

         //изменяем имя, описание, статус у task.Task с id 2
        inMemoryTaskManager.updateTask(new Task("Обновленное имя", "Обновленное описание", 2, Task.Status.DONE));
        //изменяем имя, описание у task.Epic с id 3
        inMemoryTaskManager.updateEpic(new Epic("Обновленное имя", "Обновленное описание", 3));
        //изменяем имя, описание, статус, task.Epic у task.Subtask с id 4
        inMemoryTaskManager.updateSubtask(new Subtask("Обновленное имя", "Обновленное описание", 4, Task.Status.DONE, 3));
        //изменяем имя, описание, статус у task.Subtask с id 5
        inMemoryTaskManager.updateSubtask(new Subtask("Обновленное имя", "Обновленное описание", 5, Task.Status.DONE, 7));
        //печатаем все объекты
        inMemoryTaskManager.printAllTypeTask();
        //удаляем task.Task с id 2
        inMemoryTaskManager.deleteById(2);
        //удаляем task.Epic с id 3
        inMemoryTaskManager.deleteById(3);
        //печатаем все объекты
        inMemoryTaskManager.printAllTypeTask();


       inMemoryTaskManager.getById(1);

        for (int i = 0; i < 5; i++) {
            inMemoryTaskManager.getById(5);
        }
        inMemoryTaskManager.getById(7);
        inMemoryTaskManager.getById(5);

        inMemoryTaskManager.getHistory();

        /* Интерфейс HistoryManager я вообще не использую, не думаю, что это правильно, но как его использовать,
        чтобы программа функционировала, я не знаю.
        Связанный список DoublyLinkedList у меня наполняется просмотренными задачами при обращении к методу
        getById (получение задачи по id), т.е. когда я создаю объект класса InMemoryTaskManager и вызываю у него
        метод inMemoryTaskManager.getById, то идет добавление в DoublyLinkedList.
        Получается, что связанный список DoublyLinkedList доступен только через обращение к этому объекту (inMemoryTaskManager).
        Если я обращусь к связанному списку через другой объект или через класс (он у меня static), то он будет пустой.
        Как сделать, чтобы связанный список наполнялся при вызове метода inMemoryTaskManager.getById, затем чтобы он сохранился
        и была возможность получить этот список через другой объект c типом интерфейса HistoryManager?
        То есть как создать список через один объект и использовать его через другой объект?

        И еще не понимаю, почему реализация просмотренных задач через LinkedHashSet не подходила?
        Там и повторов нет и порядок сохраняется.
        Зачем нужно было использовать связанный список?
         */
    }
}
